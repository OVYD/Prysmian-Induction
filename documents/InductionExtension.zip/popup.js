document.addEventListener('DOMContentLoaded', function() {
  // URL-ul aplicației tale Streamlit
  const baseUrl = "https://prysmian-induction.streamlit.app/"; 

  // Selectăm toate elementele care au clasa 'btn' din HTML
  const buttons = document.querySelectorAll('.btn');

  // Adăugăm funcția de click pe fiecare buton găsit
  buttons.forEach(btn => {
    btn.addEventListener('click', function() {
      // Citim parametrul specific butonului (ex: ?page=vpn, teams_tickit etc.)
      const pageParam = this.getAttribute('data-url');
      
      // Variabila pentru link-ul final
      let fullUrl;

      // --- LOGICA DE RUTARE ---
      
      // 1. Cazul Outlook Web (Extern)
      if (pageParam && pageParam.includes('outlook')) {
        fullUrl = "https://outlook.office365.com/mail/";
      } 
      
      // 2. Cazul TickIT (Teams App Link - Varianta STABILĂ)
      else if (pageParam === 'teams_tickit' || pageParam === 'teams_support') {
        // ID-ul aplicației TickIT
        const appId = "4bfb8e8b-c798-41f3-abf8-31852c3c3755";
        
        // Revenim la formatul /l/app/ care este sigur și nu dă erori de permisiune.
        // Acesta deschide pagina aplicației în Teams.
        fullUrl = `https://teams.microsoft.com/l/app/${appId}?source=app-bar-share-entrypoint`;
      } 
      
      // 3. Cazul Standard (Link intern către aplicația Induction)
      else {
        // Se adaugă parametrul la URL-ul de bază (ex: ...app/?page=mfa)
        fullUrl = baseUrl + pageParam;
      }
      
      // --- EXECUȚIA ---
      // Comanda către Chrome să deschidă link-ul final într-un tab nou
      if (fullUrl) {
        chrome.tabs.create({ url: fullUrl });
      }
    });
  });
});