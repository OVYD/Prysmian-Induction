// Configurare
const ALARM_NAME = "checkUpdates";
const CHECK_INTERVAL_MINUTES = 60; // Verifica o data pe ora

// Aici ar trebui sa fie URL-ul catre un JSON care contine "last_updated"
// De exemplu: https://api.myjson.com/induction_status
const DATA_URL = null; 

chrome.runtime.onInstalled.addListener(() => {
  console.log("IT Induction Companion Installed");
  
  // Seteaza alarma pentru verificare periodica
  chrome.alarms.create(ALARM_NAME, {
    periodInMinutes: CHECK_INTERVAL_MINUTES
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    checkforUpdates();
  }
});

async function checkforUpdates() {
  if (!DATA_URL) return; // Ieșim dacă nu avem URL configurat

  try {
    const response = await fetch(DATA_URL);
    const data = await response.json();
    
    // Luam data ultimei verificari din storage
    chrome.storage.local.get(['lastKnownUpdate'], function(result) {
      const lastKnown = result.lastKnownUpdate || 0;
      const currentUpdate = data.timestamp; // Presupunem ca JSON-ul are campul timestamp

      if (currentUpdate > lastKnown) {
        // 1. Trimitem Notificare
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icon.png',
          title: 'Procedură IT Nouă!',
          message: 'Ghidul de Induction a fost actualizat. Click pentru detalii.',
          priority: 2
        });

        // 2. Updatam badge-ul pe iconita
        chrome.action.setBadgeText({text: "NEW"});
        chrome.action.setBadgeBackgroundColor({color: "#FF0000"});

        // 3. Salvam noua data
        chrome.storage.local.set({lastKnownUpdate: currentUpdate});
      }
    });

  } catch (error) {
    console.error("Eroare la verificarea update-urilor:", error);
  }
}